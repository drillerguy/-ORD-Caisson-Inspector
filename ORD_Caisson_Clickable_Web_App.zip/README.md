# ORD Caisson Clickable Web App

This web app uses the actual numbered caisson plan and contains 270 clickable caisson numbers.

## Features
- Pan and zoom the full drawing on iPhone.
- Tap a caisson number or search directly.
- View and edit GPS coordinates, verification, status, condition, and notes.
- Add multiple photos to each caisson.
- Stores information and photos locally in the browser.
- Exports the caisson database as JSON.
- Can be installed on the iPhone Home Screen as a web app.

## Start
Host the folder on any HTTPS static website. Open index.html through the hosted URL in Safari, then tap Share > Add to Home Screen.

## Important
The current data stays on the phone/browser being used. Clearing Safari website data can erase it. A shared team version needs an online database and login.
